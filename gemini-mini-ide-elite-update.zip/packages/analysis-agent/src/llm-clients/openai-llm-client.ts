import OpenAI from "openai";
import { ChatCompletionMessageParam } from "openai/resources/chat/completions";
import { ILLMClient } from "./llm-client.interface.js";
import type { LLMClient as IncrementalLLMClient, BatchGeneratedFile } from "../generation/incremental-generator.js";
import { createHash } from "node:crypto";

interface FileSpec {
  path: string;
  purpose: string;
  category: string;
  criticality: string;
}

export class OpenAILLMClient implements IncrementalLLMClient {
  private openai: OpenAI;
  private defaultModel: string;
  private maxRetries: number;

  constructor(apiKey: string, options?: { baseUrl?: string; model?: string; maxRetries?: number; timeout?: number }) {
    const clientOptions: { apiKey: string; timeout: number; baseURL?: string } = {
      apiKey,
      timeout: options?.timeout ?? 600000 // 10 minutes timeout (large prompts can take time)
    };

    if (options?.baseUrl) {
      clientOptions.baseURL = options.baseUrl;
    }

    this.openai = new OpenAI(clientOptions);
    this.defaultModel = options?.model || "gpt-4o-mini";
    this.maxRetries = options?.maxRetries ?? 3;
  }

  async chatCompletion(
    messages: ChatCompletionMessageParam[],
    options?: {
      model?: string;
      temperature?: number;
      seed?: number;
      response_format?: { type: "json_object" | "text" };
    }
  ): Promise<any> {
    const response = await this.openai.chat.completions.create({
      model: options?.model || this.defaultModel,
      messages,
      temperature: options?.temperature,
      seed: options?.seed,
      response_format: options?.response_format,
      stream: true, // Important for incremental generation
    });
    return response;
  }

  async generateCode(prompt: string, context: string): Promise<BatchGeneratedFile[]> {
    const fileSpecs = this.extractFileSpecs(prompt);

    if (fileSpecs.length === 0) {
      console.warn("[OpenAILLMClient] No file specs found in prompt");
      return [];
    }

    const systemPrompt = this.buildSystemPrompt();
    const userPrompt = this.buildUserPrompt(prompt, context, fileSpecs);

    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const temperature = attempt === 1 ? 0.0 : 0.3 + (attempt - 1) * 0.2;

        const response = await this.openai.chat.completions.create({
          model: this.defaultModel,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          temperature,
          seed: attempt === 1 ? 42 : undefined,
          response_format: { type: "json_object" },
        });

        const content = response.choices[0]?.message?.content;
        if (!content) {
          throw new Error("Empty response from OpenAI");
        }

        const parsed = JSON.parse(content);
        const files = this.parseGeneratedFiles(parsed, fileSpecs);

        if (files.length < fileSpecs.length) {
          const missing = fileSpecs
            .filter((spec) => !files.some((f) => f.path === spec.path))
            .map((s) => s.path);
          throw new Error(`Missing files in response: ${missing.join(", ")}`);
        }

        console.log(
          `[OpenAILLMClient] Generated ${files.length} files (attempt ${attempt})`
        );
        return files;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        console.warn(
          `[OpenAILLMClient] Attempt ${attempt}/${this.maxRetries} failed:`,
          lastError.message
        );

        if (attempt < this.maxRetries) {
          await this.sleep(1000 * Math.pow(2, attempt - 1));
        }
      }
    }

    throw lastError ?? new Error("Unknown error during code generation");
  }

  private buildSystemPrompt(): string {
    return `You are an expert code generator. You generate COMPLETE, WORKING, PRODUCTION-READY code.\n\nCRITICAL RULES:\n1. Generate FULL implementations - NO placeholders, NO "TODO", NO "..."\n2. Include ALL necessary imports at the top of each file\n3. Follow TypeScript best practices with proper typing\n4. Add JSDoc comments for all exported functions, classes, and interfaces\n5. Handle edge cases and errors appropriately\n6. For data structures: implement ALL methods completely\n\nOUTPUT FORMAT:\nYou MUST respond with a JSON object containing a "files" array:\n{\n  "files": [\n    {\n      "path": "src/example.ts",\n      "content": "// Full file content here..."\n    }\n  ]\n}\n\nIMPORTANT:\n- Generate ALL requested files\n- Each file must have complete, working code\n- Do not skip any file\n- Content must be valid for the file type`;
  }

  private buildUserPrompt(
    batchPrompt: string,
    context: string,
    fileSpecs: FileSpec[]
  ): string {
    const lines: string[] = [];

    lines.push("# Code Generation Request");
    lines.push("");
    lines.push("## Files to Generate");
    lines.push("");

    for (const spec of fileSpecs) {
      lines.push(`### ${spec.path}`);
      lines.push(`- Purpose: ${spec.purpose}`);
      lines.push(`- Category: ${spec.category}`);
      lines.push(`- Criticality: ${spec.criticality}`);
      lines.push("");
    }

    if (context && context.trim().length > 0) {
      lines.push("## Context (Previously Generated Files)");
      lines.push(context);
      lines.push("");
    }

    lines.push("## Batch Information");
    lines.push(batchPrompt);
    lines.push("");

    lines.push("## Response Format");
    lines.push("Respond with JSON containing a \"files\" array with path and content for each file.");

    return lines.join("\n");
  }

  private extractFileSpecs(prompt: string): FileSpec[] {
    const specs: FileSpec[] = [];
    const lines = prompt.split("\n");

    let currentFile: Partial<FileSpec> | null = null;

    for (const line of lines) {
      const trimmed = line.trim();

      const pathMatch = trimmed.match(/^###\s+(.+\.\w+)$/);
      if (pathMatch) {
        if (currentFile?.path) {
          specs.push(this.completeFileSpec(currentFile));
        }
        currentFile = { path: pathMatch[1] };
        continue;
      }

      if (currentFile) {
        const purposeMatch = trimmed.match(/^-\s*Purpose:\s*(.+)$/i);
        if (purposeMatch) {
          currentFile.purpose = purposeMatch[1];
          continue;
        }

        const categoryMatch = trimmed.match(/^-\s*Category:\s*(.+)$/i);
        if (categoryMatch) {
          currentFile.category = categoryMatch[1];
          continue;
        }

        const criticalityMatch = trimmed.match(/^-\s*Criticality:\s*(.+)$/i);
        if (criticalityMatch) {
          currentFile.criticality = criticalityMatch[1];
          continue;
        }
      }
    }

    if (currentFile?.path) {
      specs.push(this.completeFileSpec(currentFile));
    }

    return specs;
  }

  private completeFileSpec(partial: Partial<FileSpec>): FileSpec {
    return {
      path: partial.path ?? "unknown.ts",
      purpose: partial.purpose ?? "Implementation",
      category: partial.category ?? "APPLICATION",
      criticality: partial.criticality ?? "MEDIUM",
    };
  }

  private parseGeneratedFiles(
    response: unknown,
    expectedSpecs: FileSpec[]
  ): BatchGeneratedFile[] {
    const files: BatchGeneratedFile[] = [];

    if (!response || typeof response !== "object") {
      throw new Error("Invalid response format: expected object");
    }

    const responseObj = response as Record<string, unknown>;
    const filesArray = responseObj["files"];

    if (!Array.isArray(filesArray)) {
      throw new Error('Invalid response format: missing "files" array');
    }

    for (const file of filesArray) {
      if (!file || typeof file !== "object") {
        continue;
      }

      const fileObj = file as Record<string, unknown>;
      const path = fileObj["path"];
      const content = fileObj["content"];

      if (typeof path !== "string" || typeof content !== "string") {
        continue;
      }

      const normalizedPath = path.replace(/^\.\//, "");

      const isExpected = expectedSpecs.some(
        (spec) =>
          spec.path === normalizedPath ||
          spec.path === path ||
          spec.path.endsWith(normalizedPath) ||
          normalizedPath.endsWith(spec.path)
      );

      if (!isExpected) {
        console.warn(`[OpenAILLMClient] Unexpected file in response: ${path}`);
      }

      files.push({
        path: normalizedPath,
        content,
        hash: this.computeHash(content),
      });
    }

    return files;
  }

  private computeHash(content: string): string {
    return createHash("sha256").update(content).digest("hex").slice(0, 16);
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
