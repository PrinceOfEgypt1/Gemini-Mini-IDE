/**
 * Configuração centralizada de animações cinematográficas.
 * Define variantes, transições e efeitos reutilizáveis em toda a aplicação.
 */

// ============================================================================
// TRANSIÇÕES PADRÃO
// ============================================================================

export const TRANSITIONS = {
  fast: { duration: 0.2, ease: 'easeInOut' },
  normal: { duration: 0.3, ease: 'easeInOut' },
  slow: { duration: 0.5, ease: 'easeInOut' },
  verySlow: { duration: 0.8, ease: 'easeInOut' },
  spring: { type: 'spring', stiffness: 300, damping: 30 },
  springBouncy: { type: 'spring', stiffness: 200, damping: 10 },
  springSmooth: { type: 'spring', stiffness: 100, damping: 20 },
};

// ============================================================================
// VARIANTES DE ENTRADA/SAÍDA
// ============================================================================

export const fadeInOut = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
  exit: { opacity: 0 },
};

export const slideInFromLeft = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -20 },
};

export const slideInFromRight = {
  hidden: { opacity: 0, x: 20 },
  visible: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: 20 },
};

export const slideInFromTop = {
  hidden: { opacity: 0, y: -20 },
  visible: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 },
};

export const slideInFromBottom = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: 20 },
};

export const scaleIn = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { opacity: 1, scale: 1 },
  exit: { opacity: 0, scale: 0.8 },
};

export const rotateIn = {
  hidden: { opacity: 0, rotate: -10 },
  visible: { opacity: 1, rotate: 0 },
  exit: { opacity: 0, rotate: 10 },
};

// ============================================================================
// VARIANTES DE HOVER
// ============================================================================

export const hoverScale = {
  hover: { scale: 1.05 },
};

export const hoverScaleLarge = {
  hover: { scale: 1.1 },
};

export const hoverLift = {
  hover: { y: -4 },
};

export const hoverGlow = {
  hover: { boxShadow: '0 0 20px rgba(59, 130, 246, 0.5)' },
};

// ============================================================================
// VARIANTES DE CONTAINER (STAGGER)
// ============================================================================

export const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

export const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: TRANSITIONS.normal,
  },
};

export const fastContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.1,
    },
  },
};

export const fastItemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: {
    opacity: 1,
    y: 0,
    transition: TRANSITIONS.fast,
  },
};

// ============================================================================
// VARIANTES DE MODAL
// ============================================================================

export const modalBackdropVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
  exit: { opacity: 0 },
};

export const modalContentVariants = {
  hidden: { opacity: 0, scale: 0.9, y: 20 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: TRANSITIONS.normal,
  },
  exit: {
    opacity: 0,
    scale: 0.9,
    y: 20,
    transition: TRANSITIONS.fast,
  },
};

// ============================================================================
// VARIANTES DE PROGRESSO
// ============================================================================

export const progressBarVariants = {
  hidden: { scaleX: 0 },
  visible: (width: number) => ({
    scaleX: width,
    transition: TRANSITIONS.slow,
  }),
};

export const pulseVariants = {
  animate: {
    scale: [1, 1.05, 1],
    opacity: [1, 0.8, 1],
    transition: {
      duration: 2,
      repeat: Infinity,
      ease: 'easeInOut',
    },
  },
};

// ============================================================================
// VARIANTES DE LOADING
// ============================================================================

export const spinnerVariants = {
  animate: {
    rotate: 360,
    transition: {
      duration: 2,
      repeat: Infinity,
      ease: 'linear',
    },
  },
};

export const bouncingDotsVariants = {
  animate: (i: number) => ({
    y: [0, -10, 0],
    transition: {
      duration: 1.4,
      repeat: Infinity,
      delay: i * 0.2,
      ease: 'easeInOut',
    },
  }),
};

// ============================================================================
// VARIANTES DE LISTA
// ============================================================================

export const listContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.1,
    },
  },
};

export const listItemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: TRANSITIONS.normal,
  },
};

// ============================================================================
// VARIANTES DE PÁGINA
// ============================================================================

export const pageTransitionVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: {
    opacity: 1,
    y: 0,
    transition: TRANSITIONS.normal,
  },
  exit: {
    opacity: 0,
    y: -10,
    transition: TRANSITIONS.fast,
  },
};

// ============================================================================
// EFEITOS ESPECIAIS
// ============================================================================

export const shimmerVariants = {
  animate: {
    backgroundPosition: ['200% 0%', '-200% 0%'],
    transition: {
      duration: 3,
      repeat: Infinity,
      ease: 'linear',
    },
  },
};

export const floatingVariants = {
  animate: {
    y: [0, -10, 0],
    transition: {
      duration: 3,
      repeat: Infinity,
      ease: 'easeInOut',
    },
  },
};

export const glitchVariants = {
  animate: {
    x: [0, -2, 2, -2, 0],
    transition: {
      duration: 0.3,
      repeat: Infinity,
      repeatDelay: 2,
    },
  },
};

// ============================================================================
// HELPER FUNCTION
// ============================================================================

/**
 * Combina variantes com transições personalizadas.
 */
export function withTransition(
  variants: Record<string, any>,
  transition: any = TRANSITIONS.normal
) {
  return Object.entries(variants).reduce((acc, [key, value]) => {
    acc[key] = {
      ...value,
      transition: value.transition || transition,
    };
    return acc;
  }, {} as Record<string, any>);
}
